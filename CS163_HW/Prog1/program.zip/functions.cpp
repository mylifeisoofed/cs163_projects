#include "dogs_park.h"
using namespace std;

// Brian Le
// This cpp file hosts the functions that won't be performing data abstraction.

void menu() // function to display menu.
{
	cout << "\nMain Menu\n" << endl;
	cout << "1) Add Parks\n"
		"2) Add Amenity\n"
		"3) Display List of Dog Parks\n"
		"4) Display List of Amenities from a Park\n"
		"5) Delete a park\n"
		"6) Exit\n" << endl;
}
