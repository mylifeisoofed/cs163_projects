#include "header.h"
using namespace std;

table::table(int size)
{
	hashtable_size = size;
	hashtable = new node*[size]; // size = 7

	for (int i = 0; i < size; ++i)
	{
		hashtable[i] = nullptr;
	}
}

table::~table()
{
	node * current;

	if (!hashtable)
		return;

	for (int i = 0; i < hashtable_size; ++i)
	{
		current = hashtable[i];

		while (current)
		{
			if (current->breed)
				delete [] current->breed;
			if (current->category)
				delete [] current->category;
			if (current->personality)
				delete [] current->personality;
			if (current->purpose)
				delete [] current->purpose;
			if (current->size)
				delete [] current->size;
			if (current->interest)
				delete [] current->interest;
			
			current = current->next;
			if (hashtable[i])
			{
				delete hashtable[i];
				hashtable[i] = nullptr;
			}

			hashtable[i] = current;
		}

}
	

	delete [] hashtable;
}

int table::hash_function(char * key)
{
	// Hashing technique: Add the ascii values of all the letters in the keyword
	int hashkey = 0;
	int keylength = strlen(key);

	for (int i = 0; i < keylength; ++i)
	{
		hashkey += key[i];
	}

	hashkey = hashkey % hashtable_size;

	return hashkey;
}

int table::add(char breed[], char category[], char personality[], char purpose[], char size[], char interest[], int rating)
{
	if (!breed || !category || !personality || !purpose
			|| !size || !interest || !rating)
		return 0;

	int spot = hash_function(interest);

	node * temp = new node;

	temp->breed = new char[strlen(breed) + 1];
	temp->category = new char[strlen(category) + 1];
	temp->personality = new char[strlen(personality) + 1];
	temp->purpose = new char[strlen(purpose) + 1];
	temp->size = new char[strlen(size) + 1];
	temp->interest = new char[strlen(interest) + 1];
	temp->rating = rating;
	temp->next = nullptr;

	strcpy(temp->breed, breed);
	strcpy(temp->category, category);
	strcpy(temp->personality, personality);
	strcpy(temp->purpose, purpose);
	strcpy(temp->size, size);
	strcpy(temp->interest, interest);
	temp->rating = rating;


	if (!hashtable[spot])
	{
		hashtable[spot] = temp;
		return spot;
	}

	// Otherwise,

	node * current = hashtable[spot];

	temp->next = current;

	hashtable[spot] = temp;

	return spot;
}

int table::load()
{
	char breed[100];
	char category[100];
	char personality[100];
	char purpose[100];
	char size[100];
	char interest[100];
	int rating = 0;

	ifstream file_in;

	file_in.open("animals.txt");

	if (!file_in)
	{
		return 0;
	}

	file_in.get(breed, 100, '|');
	file_in.ignore(100, '|');

	while (!file_in.eof())
	{
		file_in.get(category, 100, '|');
		file_in.ignore(100, '|');

		file_in.get(personality, 100, '|');
		file_in.ignore(100, '|');

		file_in.get(purpose, 100, '|');
		file_in.ignore(100, '|');

		file_in.get(size, 100, '|');
		file_in.ignore(100, '|');

		file_in.get(interest, 100, '|');
		file_in.ignore(100, '|');

		file_in >> rating;
		file_in.ignore(100, '\n');
		
		add(breed, category, personality, purpose, size, interest, rating);

		file_in.get(breed, 100, '|');
		file_in.ignore(100, '|');
	}

	file_in.close();

	return 1;
}

int table::display(char keyword[])
{
	node * current;

	if (!hashtable)
		return 0;

	for (int i = 0; i < hashtable_size; ++i)
	{
		current = hashtable[i];

		while (current)
		{
			if (strcmp(keyword, current->interest) == 0)
			{
				cout << "Breed: " << current->breed << endl;
				cout << "Category: " << current->category << endl;
				cout << "Personality: " << current->personality << endl;
				cout << "Purpose: " << current->purpose << endl;
				cout << "Size: " << current->size << endl;
				cout << "Interest: " << current->interest << endl;
				cout << "Rating: " << current->rating << endl;
				cout << '\n';
			}

			current = current->next;
		}
	}

	return 1;
}

int table::retrieve(char keyword[], table & petlist)
{
	node * current;

	if (!hashtable)
		return 0;

	for (int i = 0; i < hashtable_size; ++i)
	{
		current = hashtable[i];

		while (current != nullptr)
		{
			if (strcmp(current->interest, keyword) == 0)
			{
				petlist.add(current->breed, current->category, current->personality, current->purpose, current->size,
						current->interest, current->rating);
			}
			current = current->next;
		}
	}
	return 1;
}

int table::remove(char keyword[])
{
	if (!hashtable)
		return 0;

	int spot = hash_function(keyword);

	remove (keyword, hashtable[spot]);

	return 1;
}

int table::remove(char keyword[], node *& head)
{
	if (!head)
		return 0;

	if (strcmp(head->interest, keyword) == 0)
	{
		delete [] head->breed;
		delete [] head->category;
		delete [] head->personality;
		delete [] head->purpose;
		delete [] head->size;
		delete [] head->interest;
		if (head->next)
		{
			node * hold = head->next;
			delete head;
			head = hold;
		}

		else
		{
			delete head;
			head = nullptr;
		}
		return 1;
	}

	return remove(keyword, head->next);
}

int table::display_personality(char keyword[])
{
	if (!hashtable)
		return 0;

	for (int i = 0; i < hashtable_size; ++i)
	{
		display_personality(keyword, hashtable[i]);
	}

	return 1;
}

int table::display_personality(char keyword[], node * head)
{
	if (!head)
		return 0;

	if (strcmp(head->personality, keyword) == 0)
	{
		cout << "Breed: " << head->breed << endl;
		cout << "Category: " << head->category << endl;
		cout << "Personality: " << head->personality << endl;
		cout << "Purpose: " << head->purpose << endl;
		cout << "Size: " << head->size << endl;
		cout << "Interest: " << head->interest << endl;
		cout << "Rating: " << head->rating << endl;
		cout << '\n';
		return 1;
	}

	return display_personality(keyword, head->next);
}
		
