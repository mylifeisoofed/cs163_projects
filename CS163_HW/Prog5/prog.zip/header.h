#include <iostream>
#include <cctype>
#include <cstring>
#include <fstream>

struct decision
{
	char * name;
};

struct vertex
{
	decision option;
	struct node * head;
};

struct node
{
	vertex * adjacent;

	node * next;
};

class table
{
	public:
		table(); // may need to dynamically allocate later.
		~table();
		int initialize(int size);
		int insert_vertex(const decision & to_add); // insert vertex
		int findloc(char key[]); // location finder
		int insert_edge(char current[], char to_attach[]); // attatch a vertex to an existing vertex.
		int display();
		int copy(const decision & source, decision & copy_to);
		int depth(char key[]);

	private:
		vertex * list;
		bool * flag;
		int list_size;

		int remove(node * & head);

		int display(node * head);

		int depth(node * head, int loc);
};


int menu();
	
